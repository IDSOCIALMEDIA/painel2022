<html>
<head>
   <title>Basic Upload</title>
</head>
<body>
<form name="Form_Upload_Arquivo" action="upload.php" method="post" enctype="multipart/form-data">
<input type="file" name="Arquivo" />
<input type="submit" value="Enviar" />
</form>